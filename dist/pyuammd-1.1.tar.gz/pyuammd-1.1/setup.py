import sys,os

from setuptools import setup, find_packages

setup(
    packages=find_packages(),
    url="https://github.com/PabloIbannez/UAMMD-structured",
)
